package middletest;

//2021011898 ������ ���� ����� ���� ��ü ����

import java.awt.*;
import java.awt.event.*;
import java.util.Stack;
import javax.swing.*;

public class Calculator extends JFrame {
    private JTextField display;
    private JList<String> historyList;
    private DefaultListModel<String> historyModel;
    private boolean start = true;

    public Calculator() {
        setTitle("����");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ���� �г� ����
        JPanel mainPanel = new JPanel(new BorderLayout());

        // �����丮 ����Ʈ �ʱ�ȭ �� ����
        historyModel = new DefaultListModel<>();
        historyList = new JList<>(historyModel);
        historyList.setPreferredSize(new Dimension(150, 0));

        // �����丮 Ŭ�� �̺�Ʈ ����
        historyList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                String selected = historyList.getSelectedValue();
                if (selected != null && e.getClickCount() == 2) {  // ���� Ŭ���� ó��
                    // "=" ������ ������� ����
                    String result = selected.split("=")[1].trim();
                    display.setText(result);
                    start = false;
                }
            }
        });

        JScrollPane historyScroll = new JScrollPane(historyList);
        historyScroll.setPreferredSize(new Dimension(150, 0));

        // �����丮 �г� ���� (JScrollPane �߰� ��)
        JPanel historyPanel = new JPanel(new BorderLayout());
        
        // �����丮 �ʱ�ȭ ��ư �߰�
        JButton clearHistoryBtn = new JButton("��� �����");
        clearHistoryBtn.addActionListener(e -> {
            historyModel.clear();
        });
        
        historyPanel.add(historyScroll, BorderLayout.CENTER);
        historyPanel.add(clearHistoryBtn, BorderLayout.SOUTH);

        // ���� ���÷���
        display = new JTextField("0");
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setFont(new Font("���� ����", Font.BOLD, 18));
        mainPanel.add(display, BorderLayout.NORTH);

        // ���� ��ư �г� ����
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 4, 5, 5));  // 5x4 �׸���� ����

        String[] buttons = {
            "(", ")", "C", "��",
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", ".", "=", "+"
        };

        for (String button : buttons) {
            JButton btn = new JButton(button);
            if (Character.isDigit(button.charAt(0)) || button.equals(".")) {
                btn.addActionListener(new NumberListener());
            } else {
                btn.addActionListener(new CommandListener());
            }
            buttonPanel.add(btn);
        }

        // ���⿡ ��ư�г��� �����гο� �߰�
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        // ���̾ƿ� ���� (���� �ڵ� ����)
        setLayout(new BorderLayout(5, 5));
        add(mainPanel, BorderLayout.CENTER);
        add(historyPanel, BorderLayout.EAST);  // historyScroll ��� historyPanel �߰�

        setSize(400, 400);  // ������ ũ�� ����
        setLocationRelativeTo(null);
    }

    private class NumberListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            String currentText = display.getText();
            
            // ���� �޽����� ǥ�õ� �������� Ȯ��
            if (currentText.equals("Error") || 
                currentText.equals("��ȣ ����") || 
                currentText.equals("0���� ���� �� �����ϴ�")) {
                display.setText("");
                currentText = "";
            }
            
            if (start) {
                display.setText("");
                start = false;
            }

            // �Ҽ��� �Է� ó��
            if (command.equals(".")) {
                // ���� ���ڿ� �̹� �Ҽ����� �ִ��� Ȯ��
                String[] parts = display.getText().split("[+\\-*/]");
                if (parts.length > 0) {
                    String lastNumber = parts[parts.length - 1];
                    if (lastNumber.contains(".")) {
                        return; // �̹� �Ҽ����� ������ �߰� �Է��� ����
                    }
                }
            }
            
            display.setText(display.getText() + command);
        }
    }

    private class CommandListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            if (command.equals("=")) {
                try {
                    String infix = display.getText();
                    if (!isValidParentheses(infix)) {
                        display.setText("��ȣ ����");
                        return;
                    }
                    String postfix = infixToPostfix(infix);
                    double result = evaluatePostfix(postfix);
                    
                    // �Ҽ��� ó�� �߰�
                    String formattedResult;
                    if (result == (long) result) {
                        formattedResult = String.format("%d", (long) result);
                    } else {
                        formattedResult = String.format("%.7f", result);
                        // ���ڸ��� 0�� ��� ����
                        formattedResult = formattedResult.replaceAll("0*$", "");
                        // �Ҽ����� �������� ���� ��� ����
                        formattedResult = formattedResult.replaceAll("\\.$", "");
                    }
                    
                    display.setText(formattedResult);
                    
                    // ��� ��� �߰�
                    historyModel.addElement(infix + " = " + formattedResult);
                    historyList.ensureIndexIsVisible(historyModel.getSize() - 1);
                    
                    start = true;
                } catch (ArithmeticException ex) {
                    display.setText("0���� ���� �� �����ϴ�");
                    start = true;
                } catch (Exception ex) {
                    display.setText("������ �߻��߽��ϴ�");
                    start = true;
                }
            } else if (command.equals("C")) {
                display.setText("0");
                start = true;
            } else if (command.equals("��")) {
                String currentText = display.getText();
                if (currentText.length() > 0) {
                    display.setText(currentText.substring(0, currentText.length() - 1));
                    if (display.getText().isEmpty()) {
                        display.setText("0");  // ��� �������� �� "0" ǥ��
                        start = true;
                    }
                }
            } else if (command.equals("(") || command.equals(")")) {
                if (start) {
                    if (command.equals("(")) {
                        display.setText("(");
                    } else {
                        display.setText(display.getText() + ")");
                    }
                    start = false;
                } else {
                    display.setText(display.getText() + command);
                }
            } else {
                String currentText = display.getText();
                // �������� ���
                if (command.equals("+") || command.equals("-") || 
                    command.equals("*") || command.equals("/")) {
                    
                    // ���� �ؽ�Ʈ�� ������� �ʰ� ������ ���ڰ� �������� ���
                    if (!currentText.isEmpty() && isOperator(currentText.charAt(currentText.length() - 1))) {
                        // ������ �����ڸ� ���ο� �����ڷ� ��ü
                        display.setText(currentText.substring(0, currentText.length() - 1) + command);
                    } else {
                        display.setText(currentText + command);
                    }
                    start = false;
                } else {
                    display.setText(display.getText() + command);
                }
            }
        }
    }

    // ������ Ȯ���� ���� ���� �޼ҵ� �߰�
    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private int getPrecedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
        }
        return -1;
    }

    private String infixToPostfix(String infix) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < infix.length(); i++) {
            char c = infix.charAt(i);

            if (Character.isDigit(c) || c == '.') {
                result.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(' ').append(stack.pop());
                }
                if (!stack.isEmpty()) stack.pop();
            } else {
                result.append(' ');
                while (!stack.isEmpty() && getPrecedence(c) <= getPrecedence(stack.peek())) {
                    result.append(stack.pop()).append(' ');
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            result.append(' ').append(stack.pop());
        }

        return result.toString();
    }

    private double evaluatePostfix(String postfix) {
        Stack<Double> stack = new Stack<>();
        StringBuilder num = new StringBuilder();

        for (int i = 0; i < postfix.length(); i++) {
            char c = postfix.charAt(i);

            if (Character.isDigit(c) || c == '.') {
                num.append(c);
            } else if (c == ' ' && num.length() > 0) {
                stack.push(Double.parseDouble(num.toString()));
                num = new StringBuilder();
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                double val2 = stack.pop();
                double val1 = stack.pop();
                
                switch (c) {
                    case '+':
                        stack.push(val1 + val2);
                        break;
                    case '-':
                        stack.push(val1 - val2);
                        break;
                    case '*':
                        stack.push(val1 * val2);
                        break;
                    case '/':
                        if (val2 == 0) throw new ArithmeticException();
                        stack.push(val1 / val2);
                        break;
                }
            }
        }

        if (num.length() > 0) {
            stack.push(Double.parseDouble(num.toString()));
        }

        return stack.pop();
    }

    private boolean isValidParentheses(String expression) {
        Stack<Character> stack = new Stack<>();
        for (char c : expression.toCharArray()) {
            if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                if (stack.isEmpty()) return false;
                stack.pop();
            }
        }
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Calculator calc = new Calculator();
            calc.setVisible(true);
        });
    }
}
